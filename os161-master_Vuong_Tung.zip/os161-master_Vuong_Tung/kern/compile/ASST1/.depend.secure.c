secure.o: ../../../common/libtest161/secure.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
 opt-noasserts.h ../../include/kern/errno.h ../../include/kern/secure.h \
 ../../../common/libtest161/sha256.h ../../../common/libtest161/config.h
