sha256.o: ../../../common/libtest161/sha256.c \
 ../../../common/libtest161/config.h ../../../common/libtest161/sha256.h \
 ../../include/types.h ../../include/kern/types.h \
 includelinks/kern/machine/types.h includelinks/machine/types.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h
