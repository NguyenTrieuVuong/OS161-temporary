/* Automatically generated; do not edit */
#ifndef _OPT_AUTOMATIONTEST_H_
#define _OPT_AUTOMATIONTEST_H_
#define OPT_AUTOMATIONTEST 0
#endif /* _OPT_AUTOMATIONTEST_H_ */
